# c9n · Markenregeln v3

Stand: 22. September 2026. Der Dateiname bleibt für bestehende Verweise erhalten. Diese Regeln ersetzen die frühere Petrol-Palette als primäre Produktidentität.

## Name und Positionierung

**c9n** · **Cooperation** · **c9n.app**. Neun Buchstaben zwischen c und n ergeben das Numeronym. Aussprache deutsch „C-neun-N“, englisch „C-nine-N“. Produktname immer klein; keine Schreibweisen wie C9N oder Wirkivo in neuen öffentlichen Texten.

c9n hilft Unternehmen, die Zusammenarbeit von Menschen und KI zu gestalten, als Workflows auszuführen und ihre Wirkung zu überprüfen. Design, Workflow und Messung bleiben eigene, miteinander verbundene Bereiche. Die lokale Anwendung gehört zum Unternehmen; das optionale Community-Gateway vermittelt freigegebene Verbindungen.

Versprechen: **Mehr Zeit für die Arbeit, die Menschen braucht.** Englisch: **More time for the work that needs people.**

## Logo und Zeichen

Freigegebene Dateien liegen unter `c9n/`. Die geometrische Wortmarke verbindet c, 9 und n. Der Lime-Akzent zwischen c und 9 macht die Verbindung sichtbar. Als kompaktes Zeichen verwenden wir die helle 9 auf dunkelgrünem Grund. `logo.svg` verwenden wir auf hellen Flächen, `logo-dark.svg` auf dunklen Flächen. `favicon.svg` ist das kompakte Zeichen; ICO und PNG bedienen Browser, Lesezeichen und Gerätesymbole.

Logo nicht verzerren, drehen oder neu einfärben. Freiraum rundum mindestens eine halbe Zeichenhöhe. Wortmarke mindestens 96 px breit; darunter das kompakte Zeichen verwenden. Keine Schatten oder Verläufe hinzufügen. Der ältere KI-Logoentwurf ist eine Referenz, kein produktives Asset. Die App verwendet `shared/BrandLogo.vue` für denselben Aufbau mit zur Oberfläche passendem Kontrast.

## Farben

| Rolle | Hell | Dunkel |
| --- | --- | --- |
| Logo / primäre Marke | Dunkelgrün `#173E33` | Helle Wortmarke `#F6F5EF` |
| Zeichenakzent | Lime `#88BD32` | Lime `#88BD32` |
| Seitenhintergrund | Warmweiß `#F6F5EF` | `#101C18` |
| Karten | Weiß `#FFFFFF` | `#15251E` |
| Haupttext | `#173E33` | `#F3F6EC` |
| Sekundärtext | `#56685F` | `#B5C5B7` |
| Aktion | `#173E33` / weißer Text | `#A8D563` / dunkler Text |
| Gruppierung | `#E5EDDD` | `#253B28` |

Lime ist ein Akzent für das Zeichen und ausgewählte Hervorhebungen, keine Farbe für kleine Schrift auf Weiß. Zustände immer durch Text oder Symbol ergänzen. Eine Seite verwendet durchgängig ein helles oder dunkles Thema. Illustrationen dürfen zusätzliche Farben nutzen, ohne die Markenfarben zu ersetzen.

## Schrift und Gestaltung

Inter Variable, lokal gehostet, SIL-Lizenz mitliefern. Titel 750, Fließtext 400, Aktionen 600. Kontrollen 8 px Radius, größere Flächen 12 px. Ruhige Linien, großzügige Abstände und klare Hierarchie. Reduzierte Bewegung respektieren.

Designer: übersichtliche Zeichenfläche, dezentes Raster, lesbare Gruppen und Verbindungen. Workflows: unterschiedliche Aufgaben-Icons, verständliche Zustände und ein klares Verhalten für Klicken und Verschieben. Messung: Zeitraum, Ausgangswert, Quelle und fehlende Werte sichtbar machen.

## Sprache und Nachweise

Klar, menschlich, konkret. „KI bereitet den Entwurf vor. Euer Team prüft und entscheidet.“ Einsparungen nur mit vergleichbaren Messdaten nennen. Echte Produktansichten für Funktionsnachweise, Illustrationen für Zielbilder. Beispiele und Testdaten kennzeichnen. Keine erfundenen Kundenreferenzen.

## Ablage und Veröffentlichung

`branding/` ist die Quelle. `tools/sync-brand-assets.py` verteilt die Dateien und erstellt ein Markenpaket ohne historische Entwürfe oder private Präsentationen. Öffentlicher Leitfaden: `https://c9n.app/brand/`. Leitfaden in der selbst gehosteten App: `/landing/brand/`. Bestehende technische Speicher- und Datenbankschlüssel werden durch eine Umbenennung der Marke nicht verändert.
