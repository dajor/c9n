# c9n · Branding

Verbindlicher Markenstand v3 · 22. September 2026. Wir schreiben den Namen immer klein. Die öffentliche Domain ist **c9n.app**.

- [Markenleitfaden](markenleitfaden.html) mit Logos auf hellen und dunklen Flächen.
- [Markenregeln](BRANDING_V1.md): Positionierung, Farben, Typografie und Anwendung.
- [Logo, Icon und Favicons](c9n/README.md): freigegebene Originaldateien.
- [Farben und Schriftdefinitionen](farben/tokens.css).
- `schriften/`: lokal gehostete Inter Variable und SIL-Lizenz.
- [Markenpaket herunterladen](https://c9n.app/brand/c9n-brand-kit.zip).

`branding/` ist die zentrale Quelle. Nach Änderungen `python3 tools/sync-brand-assets.py` ausführen. Das synchronisiert Logos, Favicons und Markenleitfaden mit App, Editoren und dem lokalen Checkout der öffentlichen Website und erstellt das Markenpaket. Anschließend die betroffenen Websites bauen/veröffentlichen.

`referenzen/` und `vorschauen/` enthalten historische Vorlagen und Ansichten. Sie werden nicht als aktuelle c9n-Markenelemente verteilt. Die ursprüngliche Präsentation bleibt als Referenz erhalten.
