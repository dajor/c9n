# c9n brand assets

`logo.svg` is the light-surface wordmark; `logo-dark.svg` is for dark surfaces. `favicon.svg` is the shared compact mark. ICO contains 16/32/48 px PNG frames; PNG alternatives include 32 px, Apple Touch 180 px and 192/512 px.

Run `python3 tools/sync-brand-assets.py` from the repository to distribute approved exports to the application, editors and locally checked-out public product site. Versioned HTML icon links refresh previously cached icons. Keep all icon variants derived from the approved SVG.
